Esta tela está voltada para:
- Realizar o login do usuário (funcionário ou gestor)
- Abrir página "Sobre nós"
- Abrir páginas (funcionarios ou gestor)