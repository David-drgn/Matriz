Este módulo está voltado para:
- Configurar a tela inicial 
- Realizar a contagem de quantas tentativas de erro ocorreram no login