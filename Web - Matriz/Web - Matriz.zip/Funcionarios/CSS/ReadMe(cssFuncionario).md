Este modulo está voltada para:
- Configurar a tela de funcionário
- Guardar as fontes da página