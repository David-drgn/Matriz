Esta tela está voltada para:
- Mostrar as competências em suas áreas
- Mostrar equipes em que está presente
- Guardar CSS voltada para está página