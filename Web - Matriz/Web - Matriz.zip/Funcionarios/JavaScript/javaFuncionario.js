function Back() {
    window.history.back();
}

function Perguntas() {
    window.location.href = "../PerguntasFrequentesLogado/BotIndex.php";
}