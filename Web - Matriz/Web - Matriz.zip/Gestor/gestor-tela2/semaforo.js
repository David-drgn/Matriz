function semaforo() {
    document.getElementById("nivel").classList.toggle("show");
}