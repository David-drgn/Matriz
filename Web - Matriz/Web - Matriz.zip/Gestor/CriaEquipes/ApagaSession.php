<?php
$_SESSION['IDequipe'] = "";
echo "<script>window.location.href = '../gestor.php';</script>";
