function Back() {
    window.history.back()
}

function Equipes() {
    document.getElementById("Equipes").classList.toggle("Show");
}

function Semaforo() {
    document.getElementById("selecionar").classList.toggle("Show");
}

function EditarEqp() {
    document.getElementById("Menu-Editar").classList.toggle("Show");
}