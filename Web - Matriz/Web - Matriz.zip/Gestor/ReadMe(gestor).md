Este modulo está voltado para:
- Abrir a tela de funcionalidade de funcionários
- Receber as funcionalidades das equipes
- Cadastrar funcionários 
- Criar equipes