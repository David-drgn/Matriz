<?php
    include __DIR__ . '/../EsqueciSenha/EsqueciSenha.php';
?>