function BackHistory() {
    window.history.back();
}
function TelaHome() {
    window.location.href = "../HomePage/homePage.php";
}
function TelaGestor() {
    window.location.href = "../gestor.php";
}
function TelaHome2() {
    window.location.href = "../../HomePage/homePage.php";
}